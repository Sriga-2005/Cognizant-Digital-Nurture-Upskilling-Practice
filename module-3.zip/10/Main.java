/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
import java.util.Random;

class GuessNumber
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        int number = rand.nextInt(100) + 1;
        int guess;

        do
        {
            System.out.print("Guess a number (1-100): ");
            guess = sc.nextInt();

            if(guess > number)
                System.out.println("Too High!");
            else if(guess < number)
                System.out.println("Too Low!");
            else
                System.out.println("Correct! You guessed the number.");
        }
        while(guess != number);
    }
}