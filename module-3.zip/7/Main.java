/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class TypeCasting
{
    public static void main(String args[])
    {
        double d = 45.78;
        int i = (int)d;

        int num = 25;
        double d2 = (double)num;

        System.out.println("Double Value = " + d);
        System.out.println("After casting to int = " + i);

        System.out.println("Integer Value = " + num);
        System.out.println("After casting to double = " + d2);
    }
}