/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

class GradeCalculator
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Marks: ");
        int marks = sc.nextInt();

        if(marks >= 90)
            System.out.println("Grade A");
        else if(marks >= 80)
            System.out.println("Grade B");
        else if(marks >= 70)
            System.out.println("Grade C");
        else if(marks >= 60)
            System.out.println("Grade D");
        else
            System.out.println("Grade F");
    }
}