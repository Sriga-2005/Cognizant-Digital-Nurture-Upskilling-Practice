/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Main
{
    public static void main(String args[])
    {
        int num = 100;
        float f = 12.5f;
        double d = 123.456;
        char ch = 'A';
        boolean flag = true;

        System.out.println("Integer : " + num);
        System.out.println("Float : " + f);
        System.out.println("Double : " + d);
        System.out.println("Character : " + ch);
        System.out.println("Boolean : " + flag);
    }
}